﻿
Imports System.Linq
Imports System.Drawing
Public Class Form1


    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        Dim label As New Label()
        Dim count As Integer = panel1.Controls.OfType(Of Label)().ToList().Count
        label.Location = New Point(10, (25 * count) + 2)
        label.Size = New Size(40, 20)
        label.Name = "label_" & (count + 1)
        label.Text = "label " & (count + 1)
        panel1.Controls.Add(label)

        Dim textbox As New TextBox()
        count = panel1.Controls.OfType(Of TextBox)().ToList().Count
        textbox.Location = New Point(60, 25 * count)
        textbox.Size = New Size(80, 20)
        textbox.Name = "textbox_" & (count + 1)
        AddHandler textbox.TextChanged, AddressOf TextBox_Changed
        panel1.Controls.Add(textbox)

        Dim button As New Button()
        count = panel1.Controls.OfType(Of Button)().ToList().Count
        button.Location = New Point(150, 25 * count)
        button.Size = New Size(60, 20)
        button.Name = "button_" & (count + 1)
        button.Text = "Button " & (count + 1)
        AddHandler button.Click, AddressOf Button_Click
        panel1.Controls.Add(button)
    End Sub


    Private Sub TextBox_Changed(sender As Object, e As EventArgs)
        Dim textbox As TextBox = TryCast(sender, TextBox)
        MessageBox.Show(textbox.Name + " text changed. Value " + textbox.Text)
    End Sub

    Private Sub Button_Click(sender As Object, e As EventArgs)
        Dim button As Button = TryCast(sender, Button)
        MessageBox.Show(button.Name + " clicked")
    End Sub
End Class






