﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace models
{
    public class FormFieldModel
    {
        public int? Id { get; set; }
        public string MaField { get; set; }
        public string ClassificationCode { get; set; }
        public List<FormFieldModel> FormFieldList { get; set; }      

        public FormFieldModel()
        {
            FormFieldList = new List<FormFieldModel>();
        }
    }

   
   
}
