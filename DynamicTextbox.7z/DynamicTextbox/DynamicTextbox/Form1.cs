﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DynamicTextbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Label label = new Label();
            int count = panel1.Controls.OfType<Label>().ToList().Count;
            label.Location = new Point(10, (25 * count) + 2);
            label.Size = new Size(40, 20);
            label.Name = "label_" + (count + 1);
            label.Text = "label " + (count + 1);
            panel1.Controls.Add(label);

            TextBox textbox = new TextBox();
            count = panel1.Controls.OfType<TextBox>().ToList().Count;
            textbox.Location = new Point(60, 25 * count);
            textbox.Size = new Size(80, 20);
            textbox.Name = "textbox_" + (count + 1);
            textbox.TextChanged += new System.EventHandler(this.TextBox_Changed);
            panel1.Controls.Add(textbox);

            Button button = new Button();
            count = panel1.Controls.OfType<Button>().ToList().Count;
            button.Location = new Point(150, 25 * count);
            button.Size = new Size(60, 20);
            button.Name = "button_" + (count + 1);
            button.Text = "Button " + (count + 1);
            button.Click += new System.EventHandler(this.Button_Click);
            panel1.Controls.Add(button);
        }

        private void TextBox_Changed(object sender, EventArgs e)
        {
            TextBox textbox = (sender as TextBox);
            MessageBox.Show(textbox.Name + " text changed. Value " + textbox.Text);
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button button = (sender as Button);
            MessageBox.Show(button.Name + " clicked");
        }
    }
}
