﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using UserControlLibary;

namespace DynamicTextbox
{
    public partial class FormField : Form
    {
        FormFieldControl c;
        public FormField()
        {
            InitializeComponent();
            c = new FormFieldControl();
            c.Draw();

            panel1.Controls.Add(c);
        }

       
    }
}
