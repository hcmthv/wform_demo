﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
namespace UserControlLibary
{    
    public partial class FormFieldControl : UserControl
    {
        private TableLayoutPanel tableLayoutPanel1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;

        public class Fields
        {
            public string Name { get; set; }
            public string Label { get; set; }
            public string Type { get; set; }

        }

        public class Buttons
        {
            public string Name { get; set; }
            public string Action { get; set; }

            public string Type { get; set; }
        }
       public class oFieldForm
        {
            public int Count { get; set; }
            public List<Fields> FieldForm { get; set; }

            public List<Buttons> ButtonForm { get; set; }
            public oFieldForm()
            {
                FieldForm = new List<Fields>();
                ButtonForm = new List<Buttons>();
            }
        }
        public void Draw()
        {
            InitializeComponent();
            string jsonString = "{ " +
                        "'Count' : 3," +
                        "'FieldForm': [ " +
                                    "{'Name':'Id','Label': 'Id','Type':'NumberBox'}," +
                                    "{'Name':'MaField','Label': 'Ma Field','Type':'TextBox'}," +
                                    "{'Name':'ClassificationCode','Label': 'ClassificationCode','Type':'ComboBox'} ]," +
                        "'ButtonForm': [{'Name': 'Save','Action':'Save','Type':'Button'}," +
                                    "{'Name': 'Xoa','Action':'Delete','Type':'Button'}  ]" +
                        " }";

            var jsonData = JsonConvert.DeserializeObject<oFieldForm>(jsonString);
            addFieldForm(jsonData.FieldForm);

          
            addButtonForm(jsonData.ButtonForm);
        }


        private void addFieldForm(List<Fields> oFieldForm)
        {
            int tabIndex = 0;
            int handle_Count = -1;
            int handle_row = -1;
            // TableLayoutPanel Initialization
            TableLayoutPanel panel = new TableLayoutPanel();
            panel.SuspendLayout();

            panel.ColumnCount = 4;
            panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());

            panel.Dock = System.Windows.Forms.DockStyle.Fill;
            panel.Location = new System.Drawing.Point(0, 0);
            panel.Name = "tableLayoutPanel";
            panel.RowCount = 1;
            panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            panel.Size = new System.Drawing.Size(396, 238);
            panel.TabIndex = 0;

            int colSpan = 3;
            foreach (Fields c in oFieldForm)
            {
                if (handle_Count >= colSpan)
                {
                    handle_Count = -1;
                    panel.RowCount += 1;
                    panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
                }

                handle_row = panel.RowCount - 1;
                if (c.Type == "TextBox")
                {
                    TextBox textBox = new System.Windows.Forms.TextBox();
                    textBox.Dock = System.Windows.Forms.DockStyle.Fill;
                    textBox.Location = new System.Drawing.Point(201, 3);
                    textBox.Name = "textBox_" + c.Name;
                    textBox.Size = new System.Drawing.Size(230, 20);
                    textBox.TabIndex = tabIndex + 1;

                    handle_Count = handle_Count + 1;
                    panel.Controls.Add(textBox, handle_Count + 1, handle_row);
                }

                if (c.Type == "ComboBox")
                {
                    ComboBox comboBox = new System.Windows.Forms.ComboBox();
                    comboBox.Dock = System.Windows.Forms.DockStyle.Fill;
                    comboBox.Location = new System.Drawing.Point(201, 3);
                    comboBox.Name = "comboBox_" + c.Name;
                    comboBox.Size = new System.Drawing.Size(230, 20);
                    comboBox.TabIndex = tabIndex + 1;

                    handle_Count = handle_Count + 1;
                    panel.Controls.Add(comboBox, (handle_Count + 1), handle_row);
                }

                if (c.Type == "NumberBox")
                {
                    TextBox textBox = new System.Windows.Forms.TextBox();
                    textBox.Dock = System.Windows.Forms.DockStyle.Fill;
                    textBox.Location = new System.Drawing.Point(201, 3);
                    textBox.Name = "textBox_" + c.Name;
                    textBox.Size = new System.Drawing.Size(230, 20);
                    textBox.TabIndex = tabIndex + 1;

                    handle_Count = handle_Count + 1;
                    panel.Controls.Add(textBox, (handle_Count + 1), handle_row);
                }

                Label label = new System.Windows.Forms.Label();
                label.AutoSize = true;
                label.Location = new System.Drawing.Point(3, 0);
                label.Name = "label_" + c.Label;
                label.Size = new System.Drawing.Size(35, 13);
                label.TabIndex = tabIndex;
                label.Text = c.Label;

                panel.Controls.Add(label, handle_Count, handle_row);
                handle_Count += 1;
                tabIndex += 1;
            }

            // 
            // FormFieldControl
            // 
            this.Controls.Add(panel);

            panel.ResumeLayout(false);
            panel.PerformLayout();
        }
    
        private void addButtonForm(List<Buttons> oButtonForm)
        {
            int tabIndex = 0;
            int handle_Count = -1;
            int handle_row = -1;
            // TableLayoutPanel Initialization
            TableLayoutPanel panel = new TableLayoutPanel();
            panel.SuspendLayout();

            panel.ColumnCount = 1;
            panel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());            

            panel.Dock = System.Windows.Forms.DockStyle.Fill;
            panel.Location = new System.Drawing.Point(0, 0);
            panel.Name = "tableLayoutPanel1";
            panel.RowCount = 2;
            panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            panel.Size = new System.Drawing.Size(396, 238);
            panel.TabIndex = 0;

            int colSpan = 1;
            foreach (var c in oButtonForm)
            {
                /*if (handle_Count >= colSpan)
                {
                    handle_Count = -1;
                    panel.RowCount += 1;
                    panel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
                }*/

                handle_row = panel.RowCount - 1;
                if (c.Type == "Button")
                {
                    Button button = new System.Windows.Forms.Button();
                    button.Dock = System.Windows.Forms.DockStyle.Fill;
                    button.Location = new System.Drawing.Point(201, 3);
                    button.Name = "button_" + c.Name;
                    button.Size = new System.Drawing.Size(230, 20);
                    button.TabIndex = tabIndex + 1;

                    handle_Count = handle_Count + 1;
                    panel.Controls.Add(button, handle_Count + 1, handle_row);
                }
            }



            // 
            // FormFieldControl
            // 
            this.Controls.Add(panel);

            panel.ResumeLayout(false);
            panel.PerformLayout();
        }
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FormFieldControl
            // 
            this.Name = "FormFieldControl";
            this.Size = new System.Drawing.Size(652, 375);
            this.ResumeLayout(false);

        }
    }

}
