﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DynamicControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            c = new usercon(this);
        }
        usercon c;
        private void button1_Click(object sender, EventArgs e)
        {
            c.Add();
            c.TextChanged += C_TextChanged;
        }

        private void C_TextChanged(object sender, EventArgs e)
        {
            Text = ((TextBox)sender).Text;
        }

    }

    public class usercon : UserControl
    {
        public usercon(Control panel)
        {
            ParentPanel = panel;
            TextBoxes = new List<Control>();
        }

        public delegate void OnTextChangedEventHandler(object sender, EventArgs e);

        private OnTextChangedEventHandler textChanged;
        public event OnTextChangedEventHandler TextChanged
        {
            add { textChanged += value; }
            remove { textChanged -= value; }
        }

        public Control ParentPanel;
        int y = 30;
        public List<Control> TextBoxes { get; set; }
        public void Add()
        {
            TextBox txtbox = new TextBox();
            txtbox.Name = "dynamictxt";
            txtbox.Location = new Point(59, y);
            y += txtbox.Height + 2;
            txtbox.Size = new System.Drawing.Size(188, 20);
            txtbox.TextChanged += Txtbox_TextChanged; ;
            TextBoxes.Add(txtbox);
            ParentPanel.Controls.Add(txtbox);
        }

        private void Txtbox_TextChanged(object sender, EventArgs e)
        {
            if (textChanged != null)
                textChanged.Invoke(sender, e);
        }
    }
}
